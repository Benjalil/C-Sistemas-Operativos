#include <string.h>
#include<stdio.h>



int main ()
{

    int ARR[100];
    int contv=0,contc=0;
    printf("Ingrese su texto");
    scanf("%s",&ARR);


    int n= strlen(ARR);

    for (int i = 0; i < n; i++)
    {
        if (ARR[i]=="a" ||ARR[i]=="A"||ARR[i]=="e"||ARR[i]=="E",ARR[i]=="i"||ARR[i]=="I"||ARR[i]=="o"||ARR[i]=="O"||ARR[i]=="u"||ARR[i]=="U")
        {
            contv++;
        }
    }
printf("Total vocales= %i",contv);

}