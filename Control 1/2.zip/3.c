#include <string.h>
#include <stdio.h>
#include <math.h>





main ()
{







}